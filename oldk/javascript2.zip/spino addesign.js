fill(255, 0, 0);
textSize(30);
text("MATH MANIA!", 10, 30);
textSize(10);
text("YOU'LL NEVER KNOW MATH BETTER!", 10, 87);
text("STARTING NOW AT JUST $5.99!", 10, 97);
ellipse(200,200,100,100);
line(200,150,200,250);
line(200,200,250,200);