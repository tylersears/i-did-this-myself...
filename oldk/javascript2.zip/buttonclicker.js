var button = function(x, y) {
    this.x = x;
    this.y = y;
    this.clicket = false;
    this.alclciket = false;
    this.dx = 0;
    this.dy = 0;
};
button.prototype.draw = function() {
    
};
var bu = button(200, 200);
