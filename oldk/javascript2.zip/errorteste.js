if (width < 800 && height < 600) {
    throw("Canvas is way too small! " + width + " by " + height + " pixels? Enlarge it to 800 by 600 pixels by typing ?width=800&height=600 in the URL Adress!");
} else {
    throw("You listned to an error message?!?! trust yourself!");
}