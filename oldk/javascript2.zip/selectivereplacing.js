println('class'.replace(/c[a-z][a-z][a-z]s/, 'claus'));
