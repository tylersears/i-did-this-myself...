background(186, 145, 20); // wooden table
ellipse(200, 200, 350, 350); // plate
ellipse(200, 200, 300, 300); 
fill(117, 0, 113);
ellipse(82,200,50,50);
ellipse(90,250,50,50);
fill(83, 219, 115);
ellipse(200,200,177,177);
fill(87, 66, 2);
ellipse(82,200,5,5);
ellipse(90,250,5,5);
