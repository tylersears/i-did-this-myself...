fill(255, 0, 0);
noStroke();
for (var i = 0; i < 8; i++) {
ellipse(1, 1, 1, 1);
scale(2);
ellipse(1, 1, 1, 1);
}
