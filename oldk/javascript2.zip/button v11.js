



var x = 0;
draw = function() {
    background(148, 148, 148);

mouseClicked = function(){
    if(mouseX<270&&mouseY<325&&mouseX>120&&mouseY>180){
        
    
    x++;
}

    };
    var circle = 195;
 noStroke();
fill(196, 0, 0);
ellipse(187,252,154,146);
fill(255, 61, 61);
ellipse(circle,252,145,145);


    textSize(10);
   text("Click the button as much as you can!",4,392);
   textSize(27);
fill(255, 0, 0);
if(x===0){
   

fill(255, 0, 0);
textSize(27);

text("                A button. \nDo not push,click,poke,touch,\ntap,pat,come in contact with it,\n or go anywhere near this button.\n\n\n\n\n\n\n         This MY button!!!",3,54);
}
noStroke();


if(x===1){
text("Why did you click it?!?",45,45);
}
if(x===2){
    text("It said not to.",45,45);
}
if(x===3){
    text("Stop",45,45);
}
if(x===4){
    text("stop!",45,45);
}
if(x===5){
    text("Stop!!",45,45);
}
if(x===6){
    text("That's enough.",45,45);
}
if(x===7){
    text("Haha.The button moved.",45,45);
    fill(255, 0, 0);
ellipse(70,252,149,145);
fill(255, 61, 61);
ellipse(75,252,145,145);
fill(148, 148, 148);
rect(137,170,250,250);
rect(134,166,45,45);
rect(134,289,45,45);
}
if(x===8){
     text("That didn't fool you?Fine.",45,45);
}
if(x===9){
 text("I'll change your cursor.\nWill you go away now?",45,45); 
 image(getImage("creatures/OhNoes"),mouseX-0,mouseY-0,45,45);
}
if(x===10){
 text("      No?  Why not?",45,45);   
}
if(x===11){
 text("Are you giving me the silent\n        treatment?!?",45,45);   
}

if(x===12){
 text("Very well, I won't talk to you!",36,45);   
}
if(x===13){
 text("I'm sorry, it's just tooooooo\n tempting!!!",45,45);   
}
if(x===14){
 text("How about...\n",45,45);   
}
if(x===15){
 background(38, 0, 255);
 text("           ...ME changing the...\n            background color!!",0,45);   
}
if(x===16){
    text("Your STILL here!?!",45,45);
}
if(x===17){
    text("    You're very commited,\n     I will give you that.",45,45);
}
if(x===18){
    text("Now would you stop\n pushing my button?!?",79,45);
}
if(x===19){
    text("Stop wasting your time\n pushing this button.",45,45);
}
if(x===20){
    text("I'm warning you...",45,45);
}
if(x===21){
    text("Alright, see you later.",45,45);
}
if(x===30){
    text("Why are you still here?",45,45);
}
if(x===31){
    text("Go away!",45,45);
}

if(x===32){
    text(" How about you do\n something else?",45,45);
}
if(x===33){
    text("Like chess?",45,45);
}
if(x===34){
    text("NO?!?",45,45);
}
if(x===35){
    text("How about checkers?",45,45);
}if(x===36){
    text("NO!?!?!?",45,45);
}
if(x===37){
    text("Your last chance is here.\nHow about a\n different program?",45,45);
}
if(x===38){
    text("You still want to press\n this button? Really?",45,45);
}
if(x===39){
    text("Don't you have anything\n better to do?",45,45);
}
if(x===40){
    text("No...Oh well then...",45,45);
}
if(x===41){
    textSize(91);
    text("BOO!!",45,69);
}
if(x===42){
    textSize(30);
    text("Did I scare you?NO?!?",45,45);
}
if(x===43){
    text("You are very hard to\n get rid of.",45,45);
}
if(x===44){
    text("Maybe if I payed you,\n you would go away...",45,45);
}
if(x===45){
    text("Nope, no, nada.\n Can't do that.",45,45);
}
if(x===46){
    text("What does it take for\n you to go away?!?",45,45);
} if(x===47){
    

    text("For the program to end?",45,45);
}
if(x===48){
    text("Okay, but I can't do that.\nI have to guard the button.",45,45);
}
if(x===49){
    text("You ask why?",45,45);
}
if(x===50){
    text("Because this button destroys\n the world at 100 clicks.",3,45);
}
if(x===51){
    text("Alright.\nI warned you , so it's not\n my fault if you end the world",5,45);
}
if(x===52){
    text("I'm getting bored.",45,45);
}
if(x===53){
    text("I bet you're getting bored to.",45,45);
}
if(x===54){
    text("So maybe you could...",45,45);
}
if(x===55){
    text("STOP PRESSING\n MY BUTTON!!! ",4,45);
}
if(x===56){
    text("No. OK",45,45);
}
if(x===57){
    text("Go ahead press my button.",33,45);
}
if(x===58){
    text("See if I care.",45,45);
}
if(x===59){
    text("I don't care, but Maybe you\nwould like a better button.",4,352);
    fill(random(0,196),random(0,255),random( 0,255));
ellipse(193,92,149,145);

ellipse(195,92,145,145);

}
if(x===60){
    text("No.",45,45);
}
if(x===61){
    text("N0.",45,45);
}
if(x===62){
    text("NO!",45,45);
}
if(x===63){
    text("Stop, just STOOPP!!!",45,45);
}
if(x===64){
    text("Please there's\n only a few clicks left!!",45,45);
}
if(x===65){
    text("Oh no.There's only 10 left.",45,45);
}
if(x===66){
    text("9",45,45);
}
if(x===67){
    text("8",45,45);
}
if(x===68){
    text("7",45,45);
}
if(x===69){
    text("6",45,45);
}
if(x===70){
    text("5",45,45);
}if(x===71){
    text("4",45,45);
}
if(x===72){
    text("3\n Stop pleeeaase!!!",45,45);
}
if(x===73){
    text("2\nI'm begging.\n Listen to me I'm begging!!",45,45);
}
if(x===74){
    text("1\nTell my family I love them.\nGoodbye,World!!!",45,45);
}
if(x>=75&&x<=77){
    background(0, 0, 0);
    fill(random(200,255),random(0,255),random(0,255));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
}
if(x===78){
    text("HahaHahahahahhahahahahah\nHahaHahahahahhahahahaha\nHahaHahahahahhahahahahah\nHahaHahahahahhahahahaha\nHahaHahahahahhahahahahah\nHahaHahahahahhahahahaha\nHahaHahahahahhahahahahah\nHahaHahahahahhahahahaha\nHahaHahahahahhahahahahah\nHahaHahahahahhahahahaha\nHahaHahahahahhahahahahah\nHahaHahahahahhahahahaha\n",5,12);
}
if(x===79){
    text("I tricked you, haha.(tear)",45,45);
}
if(x===80){
    text("The world ends at 100 clicks.\n            Your at 80!",4,45);
}
if(x===81){
    text("Ok, enough of the fun.",4,45);
}
if(x===82){
    text("I have to figure out\n what's keeping you here.",4,45);
}
if(x===83){
    text("WHAT'S KEEPING YOU\n            HERE?!!?",29,45);
}
if(x===84){
    text("Maybe theres something\n wrong with you...",45,45);
}

if(x===85){
    text("WHAT'S WRONG WITH YOU?",17,45);
}
if(x===86){
    text("Your clicking\n a button that ENDS\n the WORLD forever!",45,45);
}
if(x===87){
    text("Do you want that?",45,45);
}
if(x===88){
    text("YES?!?!",45,45);
}
if(x===89){
    text("Might as well tell you\n when it happens. \n       :(",45,45);
}
if(x===90){
    text("10\nI'll ask you again.\nDo you really want this?",45,45);
}
if(x===91){
    text("9\nIs someone paying you?",45,45);
}
if(x===92){
    text("8\nNo.Okay.",45,45);
}
if(x===93){
    text("7\nMaybe you will answer...",45,45);
}
if(x===94){
    text("6\nWhen I ask you...",45,45);
}
if(x===95){
    text("5\nWhy do you want this?",45,45);
}
if(x===96){
    text("4\nI still don't understand.",45,45);
}
if(x===97){
    text("3\nOh...",45,45);
}
if(x===98){
    text("2\nWait...",45,45);
}
if(x===99){
    text("1\nYou were pushing the button\nbecause the program told you to\n in one of the corners?!?!?!",0,45);
}
if(x===100){
 background(0, 0, 0);
    fill(random(200,255),random(0,255),random(0,255));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    fill(255, 0, 0);
    textSize(200);
    text("0...",76,282);
}
if(x===101){
    textSize(25);
    text("Your pressing the button\n even though the world just ended?",0,45);
}
    if(x===102){
    textSize(25);
    fill(255, 0, 0);
    text("Do something better, \n like colonize a planet!",40,45);
}
if(x===103){
    text("How about you just stop \ntorturing this button.",0,45);
}
if(x===104){
    text("Why don't you think about it?",4,45);
}
if(x===105){
    text("It doesn't get to sleep\n because of you!",4,45);
}
if(x===106){
    text("You click this button to much!",11,45);
}
if(x===107){
    text("Wait...",54,45);
}
if(x===108){
    text("When do you sleep?",54,45);
}
if(x===109){
    text("Do you do anything else?",54,45);
}
if(x===110){
    text("No?!?",54,45);
}
if(x===111){
    text("You sit here all day until you\n destroy the universe...",5,45);
}
if(x===112){
    text("And  destroy yourself?!?",54,45);
}
if(x===113){
    text("You must get really bored\n destroying planets!",7,45);
}
if(x===114){
    text("So how about you relax and...",33,45);
}
if(x===115){
    text("STOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\nSTOP  STOP STOP STOP STOP\n",1,19);
}
if(x===116){
    text("Pressing this button!!!!!!!!!!!!!!!!!!!!!",4,45);
}
if(x===117){
    text("Please, I want to go to sleep\n to!",54,45);
}
if(x===118){
    text("Oooh...",54,45);
}
if(x===119){
    text("I have an idea...",54,45);
}
if(x===120){
    text("There are people coming!",54,45);
}
if(x===121){
    text("RUN!!!",54,45);
}
if(x===122){
    text("SERIOUSLY!!!\nRUN!!!",54,45);
}
if(x>=123&&x<=127){
     
image(getImage("creatures/OhNoes"), random(-25, 400), random(-25, 400));
image(getImage("avatars/leafers-ultimate"), random(-25, 400), random(-25, 200));
image(getImage("avatars/marcimus"), random(-25, 400), random(-25, 400));
image(getImage("avatars/mr-pink"), random(-10, 400), random(-25, 400));
image(getImage("avatars/piceratops-ultimate"), random(-25, 400), random(-25, 400));
image(getImage("avatars/mr-pants"), random(-25, 400), random(-25, 400));
image(getImage("avatars/spunky-sam"), random(-25, 400), random(-25, 400));
image(getImage("creatures/Hopper-Cool"), random(-25, 400), random(-25, 400));
image(getImage("creatures/Winston"), random(-25, 400), random(-25, 400));
image(getImage("avatars/leaf-green"), random(-25, 400), random(-25, 400));
if(x===124){
    text("GO AWAY!!!",54,45);
}
if(x===125){
    text("Please Avatars!",54,45);
}
if(x===126){
    text("UGGH!!!",54,45);
}
if(x===127){
    text("Look, It's  Salman  Khan!!!",54,45);
}

}
if(x===128){
    text("Sorry...",54,45);
}
if(x===129){
    text("REALLY, Your\n still here after that!!!",54,45);
}
if(x===130){
    text("Why,(sniffle) won't you\n go away?",54,45);
}
if(x===131){
    text("Oh...",54,45);
}
if(x===132){
    text("YOU FOUND OUT!?!?!?",54,45);
}
if(x===133){
    text("Wow, I didn't know you\n wanted to...",54,45);
}
if(x===134){
    text("DESTROY THE ENTIRE\n                                   UNIVERSE\n      AT 200 CLICKS!!!",1,45);
}
if( x===135){
    text("You didn't know!?!",45,45);
}
if( x===136){
    text("OH NO!!!I may have destroyed\n the universe!!!",15,45);
}
if(x===137){
    text("You have a way of \n getting information out of\n people. You know that?",0,45);
}
if(x===138){
    text("Look, I have to say\n......",54,45);
}
if(x===139){
    text("That if you have a job for clicking \n buttons endlessly,  annoying\n people and destroying things...",0,45);
}
if(x===140){
    text("YOUR GOOD AT IT!!",21,45);
}
if(x===141){
    text("Maybe I should\njust analyze you.",21,45);
}
if(x===142){
    text("You have a problem with\n buttons.",21,45);
}
if(x===143){
    text("You want to destroy\n the universe.",21,45);
}
if(x===144){
    text("And you keep giving\n me this endless...",21,45);
}
if(x===145){
    text("SILENT TREATMENT!!!",21,45);
}
if(x===146){
    text("Will you ever talk?",21,45);
}
if(x===147){
    text("Yes!?!Great!",21,45);
}
if(x===148){
    text("When?",21,45);
}
if(x===149){
    text("Once you destroy the Universe?",13,45);
}
if(x===150){
    text("Oh, COME ON!",21,45);
}
if(x===151){
    text("I wanted to make an agreement!",11,45);
}
if(x===152){
    text("But apperently you just want to\n destroy the Universe.",21,45);
}
if(x===153){
    text("You want something else?",21,45);
}
if(x===154){
    text("Like what?",21,45);
}
if(x===155){
    text("Cake?!?!",21,45);
}
if(x===156){
    text("Will you stop pressing the\n button if I give you cake?",21,45);
}
if(x===157){
    text("No?",21,45);
}
if(x===158){
    text("Fine.\nI'll do something else though.",21,45);
}
if(x===159){
    text("Sorry.\nI can't do it unless\n you click that button>>>>>^\n instead.",21,45);
    fill(87, 87, 87);
    ellipse(358,58,45,45);
    fill(166, 166, 166);
    ellipse(356,58,45,45);

}
if(x===160){
    text("I thought we had a deal!",21,45);
}
if(x===161){
    text("I'm going to stop\n projecting messages!",21,45);
}
if(x===165){
    text("I'm sorry,\nWHY ARE YOU STILL HERE?!!?",3,45);
}
if(x===166){
    text("Oh, I forgot to\n put the message away!",21,45);
}
if(x===167){
    text("There, now go away!",21,45);
    fill(148, 148, 148);
    rect(-92,378,312,45);
}
if(x===168){
    text("I said go away!",21,45);
}
if(x===169){
    text("GO AWAY!",21,45);
}



if(x===170){
    text("I'm warning you!",21,45);
}
if(x===171){
    text("Fine.",21,45);
}
if(x===172){
    text("I'm getting Oh Noes!!!",21,45);
}
if(x===173){
    text("Hi, Oh Noes!",21,45);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("Hi,\nKlingONMaster!",104,98);

}
if(x===174){
    text("Could you tell this person\nto go away!",21,36);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("What he said!",104,98);
}
if(x===175){
    text("A little more spirit\n Oh Noes!",24,22);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("Please,\nGo away!",104,98);
}
if(x===176){
    text("Threaten the person!!",21,25);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("Or I will...\nUhh...",104,98);
}
if(x===177){
    text("Oh forget It!",21,31);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("Ok,\nKlingONMaster!",104,98);
}
if(x===178){
     text("Why are you still here\n Oh noes?",21,30);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("I don't know!",104,98);
}
if(x===179){
     text("Goood, riddence Oh Noes!",21,35);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("Wait,\nKlingONMaster!",104,98);
}
if(x===180){
   text("What Oh Noes?!?!",21,35);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("That's Good\nridd'A'nce!",104,98); 
}
if(x===181){
    text("Go, Away Oh Noes!!!",21,35);
    image(getImage("creatures/OhNoes"),262,132);
    fill(255, 255, 255);
    rect(103,75,199,70);
    fill(0, 0, 0);
    text("OK.",167,98);
}
if(x===182){
    text("Uggh...",21,45);
}
if(x===183){
    text("Oh Noes is almost as\n bad as You!!!",21,45);
}
if(x===184){
    text("Keyword:'ALMOST'",21,45);
}
if(x===185){
    text("Oh Noes wasted a lot\n of my time! ",21,45);
}
if(x===186){
    text("Back to buisness...",21,45);
}
if(x===187){
    text("GO AWAY, OR I'LL...",21,45);
}
if(x===188){
    text("I'll, i'll...",21,45);
}
if(x===189){
    text("I give up.\n Just destroy the universe.",21,45);
}
if(x===190){
    text("Go ahead it's\n only 10 clicks away...",21,45);
}
if(x===191){
    text("Wait...",45,45);
}
if(x===192){
    text("10 CLICKS AWAY!!!",45,45);
}
if(x===193){
    text("Pleeeease...",45,45);
}
if(x===194){
    text("There are so many things\n I haven't done in life!!",45,45);
}
if(x===195){
    text("Think about it...\nYou will end to!!!",45,45);
}
if(x===196){
    text("You won't?",45,45);
}
if(x===197){
    text("How?!?!",45,45);
}
if(x===198){
    text("No time! It's only two\n clicks away!!!",59,54);
        
    
}
if(x===199){
    text("Goodbye, button.\nGoodbye, Pluto.\nGOODBYE, UNIVERSE!!!",2,45);
}
if(x>=200 && x < 250){
    background(0, 0, 0);
    fill(random(0,255),random(0,255),random(0,255));
    ellipse(random(0,400),random(0,400),random(1,100),random(1,100));
    ellipse(random(0,400),random(0,400),random(1,100),random(1,100));
    ellipse(random(0,400),random(0,400),random(1,100),random(1,100));
    ellipse(random(0,400),random(0,400),random(1,100),random(1,100));
    ellipse(random(0,400),random(0,400),random(1,100),random(1,100));
    ellipse(random(0,400),random(0,400),random(1,100),random(1,100));
    ellipse(random(0,400),random(0,400),random(1,100),random(1,100));
    ellipse(random(0,400),random(0,400),random(1,100),random(1,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    rect(random(0,400),random(0,400),random(10,100),random(10,100));
    fill(255, 0, 0);
    text("There is nothing.",97,45);
}
if (x >= 250) {
    background(0, 0, 0);
    text("void", 173, 45);
}
text(x, 0, 359);
};
