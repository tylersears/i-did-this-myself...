var draw = function() {
    if (mouseIsPressed){
    ellipse(mouseX,mouseY,10,10);
    }
};
