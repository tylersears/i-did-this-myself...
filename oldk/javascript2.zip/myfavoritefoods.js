fill(255, 0, 0);
textSize(30);
text("My Favorite Foods: ", 10, 50);
text("1. Lobster", 10, 90);
text("2. Steak", 10, 130);
text("3. Grapes",10, 170);